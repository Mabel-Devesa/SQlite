package com.exercicis.mabel.act5_sqlite;

import android.app.ListActivity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase db;
    Button afegir;
    Button esborrar;
    Button llistar;
    EditText nom;
    EditText propietari;
    EditText raça;
    ListView llistat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Declaracio i creació de la Base de Dades
        db = openOrCreateDatabase("Mascotes", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS mascotes (Nom VARCHAR, Propietari VARCHAR, Raça VARCHAR);");

        //Capturar els elements en java
        afegir = (Button) findViewById(R.id.afegir);
        esborrar = (Button) findViewById(R.id.esborrar);
        llistar = (Button) findViewById(R.id.llistar);
        llistat = (ListView) findViewById(R.id.list);
        nom = (EditText) findViewById(R.id.nom);
        propietari = (EditText) findViewById(R.id.propietari);
        raça = (EditText) findViewById(R.id.raça);

        //Els metodes onClick dels botons
        afegir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                db.execSQL("INSERT INTO mascotes VALUES('" + nom.getText().toString() + "','" + propietari.getText().toString() + "','" + raça.getText().toString() + "')");
            }
        });

        esborrar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                db.execSQL("DELETE FROM mascotes WHERE Nom = '" + nom.getText().toString() + "' AND Propietari = '" + propietari.getText().toString() + "'");
            }
        });

        llistar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Listar();
            }
        });

    }

    public void Listar() {
        ArrayAdapter<String> adaptador;
        List<String> llista = new ArrayList<String>();

        Cursor c = db.rawQuery("SELECT * FROM mascotes", null);

        if (c.getCount() == 0)
            llista.add("No hay registros");
        else {
            while (c.moveToNext()) {
                llista.add(c.getString(0) + "-" + c.getString(1));
                adaptador = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, llista);
                llistat.setAdapter(adaptador);
            }
        }
    }

}
